import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { ThemeProvider } from "./components/theme-provider";
import Home from "./page/Home";
import AboutPage from "./page/About";
import Service from "./page/Service";
import ContactPage from "./page/Contact";
import Login from "./page/Login";
import { Head } from "./page/Head";
import { Todo } from "./page/Todo";
import Project from "./page/Project";
import { RPS } from "./page/RPS";
import Movie from "./page/Movie.jsx";

const router = createBrowserRouter([
  {
    path: "/",
    element: <Home />,
  },
  {
    path: "/About",
    element: <AboutPage />,
  },
  {
    path: "/Service",
    element: <Service />,
  },
  {
    path: "/Contact",
    element: <ContactPage />,
  },
  {
    path: "/Login",
    element: <Login />,
  },
  {
    path: "/Project",
    element: <Project />,
  },
  {
    path: "/Head",
    element: <Head />,
  },
  {
    path: "/Todo",
    element: <Todo />,
  },
  {
    path: "/RPS",
    element: <RPS />,
  },
  {
    path: "/Movie",
    element: <Movie />,
  },
]);

function App() {
  return (
    <ThemeProvider>
      <RouterProvider router={router} />
    </ThemeProvider>
  );
}

export default App;
