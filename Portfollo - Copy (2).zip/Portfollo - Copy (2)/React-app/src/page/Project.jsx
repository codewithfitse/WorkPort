import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ExternalLink, Github, Eye } from "lucide-react";
import Header from "../components/Header";
import Footer from "../components/Footer";
import { Button } from "../components/ui/button";

const Project = () => {
  const projects = [
    {
      title: "Head & Tail",
      description:
        "Classic coin flip game with modern design and statistics tracking.",
      image: "/Head.png",
      category: "Game",
      technologies: ["JavaScript", "HTML5", "CSS3"],
      liveUrl: "/Head",
      githubUrl: "https://github.com/codewithfitse",
      external: false,
    },
    {
      title: "Todo Application",
      description:
        "Feature-rich task management app with local storage and modern UI.",
      image: "/demo.png",
      category: "Productivity",
      technologies: ["React", "LocalStorage", "TailwindCSS"],
      liveUrl: "/Todo",
      githubUrl: "https://github.com/codewithfitse",
      external: false,
    },
    {
      title: "Rock Paper Scissors",
      description:
        "Interactive game with AI opponent and beautiful animations.",
      image: "/demo1.png",
      category: "Game",
      technologies: ["JavaScript", "HTML5", "CSS3"],
      liveUrl: "/RPS",
      githubUrl: "https://github.com/codewithfitse",
      external: false,
    },
    {
      title: "Movie Search App",
      description:
        "A modern movie discovery platform with real-time search and filtering capabilities.",
      image: "/demo.png",
      category: "Web App",
      technologies: ["React", "Node.js", "API Integration"],
      liveUrl: "https://movies-search-web-r8ah.vercel.app/",
      githubUrl: "https://github.com/codewithfitse",
      external: true,
    },
    {
      title: "Expense Tracker",
      description:
        "Personal finance management app with expense categorization and reporting.",
      image: "/Expense.jpg",
      category: "Finance",
      technologies: ["React", "Chart.js", "LocalStorage"],
      liveUrl: "https://expense-tracker-rose-omega.vercel.app",
      githubUrl: "https://github.com/codewithfitse",
      external: true,
    },
    {
      title: "Weather API",
      description:
        "Real-time weather application with location-based forecasts and beautiful UI.",
      image: "/Weather.png",
      category: "Utility",
      technologies: ["JavaScript", "Weather API", "Geolocation"],
      liveUrl: "https://weather-app-pied-omega-79.vercel.app",
      githubUrl: "https://github.com/codewithfitse",
      external: true,
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <section className="py-20 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h1 className="text-3xl md:text-4xl font-heading font-bold text-foreground mb-4">
              All Projects
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              A comprehensive collection of my work showcasing various
              technologies and problem-solving approaches.
            </p>
          </motion.div>

          {/* Projects Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <motion.div
                key={project.title}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                viewport={{ once: true }}
                whileHover={{ y: -8 }}
                className="group relative bg-card rounded-xl overflow-hidden border border-border hover:border-primary/50 transition-all duration-300"
              >
                {/* Project Image */}
                <div className="relative overflow-hidden aspect-video">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                  {/* Overlay Content */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="flex space-x-4">
                      <Button
                        size="sm"
                        asChild
                        className="bg-white/20 backdrop-blur-sm hover:bg-white/30"
                      >
                        {project.external ? (
                          <a
                            href={project.liveUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            <ExternalLink className="h-4 w-4 mr-2" />
                            Live Demo
                          </a>
                        ) : (
                          <Link to={project.liveUrl}>
                            <Eye className="h-4 w-4 mr-2" />
                            View Demo
                          </Link>
                        )}
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Project Info */}
                <div className="p-6">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <span className="text-xs font-medium text-primary bg-primary/10 px-2 py-1 rounded-full">
                        {project.category}
                      </span>
                    </div>
                    <a
                      href={project.githubUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-muted-foreground hover:text-foreground transition-colors"
                    >
                      <Github className="h-5 w-5" />
                    </a>
                  </div>

                  <h3 className="text-xl font-bold text-foreground mb-2 group-hover:text-primary transition-colors">
                    {project.title}
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed mb-4">
                    {project.description}
                  </p>

                  {/* Technologies */}
                  <div className="flex flex-wrap gap-2">
                    {project.technologies.map((tech, techIndex) => (
                      <span
                        key={techIndex}
                        className="text-xs bg-muted px-2 py-1 rounded-md text-muted-foreground"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* CTA Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mt-16"
          >
            <div className="bg-gradient-to-r from-primary/10 to-primary/5 rounded-xl p-8 border border-primary/20">
              <h3 className="text-2xl font-heading font-bold text-foreground mb-4">
                Interested in Working Together?
              </h3>
              <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                Let's discuss your next project and how I can help bring your
                ideas to life.
              </p>
              <Button asChild size="lg">
                <Link to="/Contact">
                  Start a Project
                  <ExternalLink className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Project;
