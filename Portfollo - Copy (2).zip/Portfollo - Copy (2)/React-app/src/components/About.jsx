import React from "react";
import { motion } from "framer-motion";
import { Code, Database, Palette, Smartphone, Globe, Zap } from "lucide-react";

const About = () => {
  const skills = [
    {
      category: "Frontend",
      icon: Palette,
      skills: [
        { name: "React", level: 95 },
        { name: "JavaScript", level: 90 },
        { name: "TypeScript", level: 85 },
        { name: "TailwindCSS", level: 92 },
        { name: "HTML/CSS", level: 95 },
      ],
    },
    {
      category: "Backend",
      icon: Database,
      skills: [
        { name: "Node.js", level: 88 },
        { name: "Express.js", level: 85 },
        { name: "MongoDB", level: 80 },
        { name: "PostgreSQL", level: 75 },
        { name: "REST APIs", level: 90 },
      ],
    },
    {
      category: "Tools & Others",
      icon: Zap,
      skills: [
        { name: "Git", level: 88 },
        { name: "Docker", level: 70 },
        { name: "AWS", level: 65 },
        { name: "Figma", level: 75 },
        { name: "Agile", level: 85 },
      ],
    },
  ];

  const experiences = [
    {
      year: "2023 - Present",
      title: "Full-Stack Developer",
      company: "Freelance",
      description:
        "Building modern web applications and providing technical solutions for clients worldwide.",
    },
    {
      year: "2022 - 2023",
      title: "Frontend Developer",
      company: "Tech Startup",
      description:
        "Developed responsive user interfaces and improved user experience across multiple platforms.",
    },
    {
      year: "2021 - 2022",
      title: "Junior Developer",
      company: "Digital Agency",
      description:
        "Collaborated with design teams to implement pixel-perfect interfaces and interactive features.",
    },
  ];

  const SkillBar = ({ skill }) => (
    <div className="space-y-2">
      <div className="flex justify-between text-sm">
        <span className="text-foreground font-medium">{skill.name}</span>
        <span className="text-muted-foreground">{skill.level}%</span>
      </div>
      <div className="w-full bg-muted rounded-full h-2">
        <motion.div
          initial={{ width: 0 }}
          whileInView={{ width: `${skill.level}%` }}
          transition={{ duration: 1, delay: 0.2 }}
          viewport={{ once: true }}
          className="bg-gradient-to-r from-primary to-primary/60 h-2 rounded-full"
        />
      </div>
    </div>
  );

  return (
    <section id="about" className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <div className="space-y-4">
              <motion.h2
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2, duration: 0.6 }}
                viewport={{ once: true }}
                className="text-3xl md:text-4xl font-heading font-bold text-foreground"
              >
                About Me
              </motion.h2>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4, duration: 0.6 }}
                viewport={{ once: true }}
                className="w-20 h-1 bg-gradient-to-r from-primary to-primary/60 rounded-full"
              />
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6, duration: 0.6 }}
              viewport={{ once: true }}
              className="space-y-6 text-muted-foreground leading-relaxed"
            >
              <p>
                I'm a passionate full-stack developer with a deep love for
                creating exceptional digital experiences. My journey in
                technology began with curiosity and has evolved into a career of
                building solutions that make a real impact.
              </p>
              <p>
                With expertise in modern web technologies, I specialize in
                React, Node.js, and AI integration. I believe in writing clean,
                maintainable code and creating user experiences that are both
                beautiful and functional.
              </p>
              <p>
                When I'm not coding, you'll find me exploring new technologies,
                contributing to open-source projects, or sharing knowledge with
                the developer community. I'm always excited to take on new
                challenges and learn from every project.
              </p>
            </motion.div>

            {/* Experience Timeline */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8, duration: 0.6 }}
              viewport={{ once: true }}
              className="space-y-6"
            >
              <h3 className="text-xl font-semibold text-foreground">
                Experience
              </h3>
              <div className="space-y-4">
                {experiences.map((exp, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ delay: 1 + index * 0.1, duration: 0.5 }}
                    viewport={{ once: true }}
                    className="flex gap-4"
                  >
                    <div className="flex-shrink-0 w-24 text-sm text-primary font-medium">
                      {exp.year}
                    </div>
                    <div className="space-y-1">
                      <h4 className="font-semibold text-foreground">
                        {exp.title}
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        {exp.company}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {exp.description}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </motion.div>

          {/* Skills */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <div className="space-y-4">
              <h3 className="text-2xl font-heading font-bold text-foreground">
                Skills & Expertise
              </h3>
              <p className="text-muted-foreground">
                Here's a breakdown of my technical skills and proficiency
                levels.
              </p>
            </div>

            <div className="space-y-8">
              {skills.map((category, categoryIndex) => (
                <motion.div
                  key={category.category}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: categoryIndex * 0.2, duration: 0.6 }}
                  viewport={{ once: true }}
                  className="space-y-4"
                >
                  <div className="flex items-center gap-3">
                    <category.icon className="h-6 w-6 text-primary" />
                    <h4 className="text-lg font-semibold text-foreground">
                      {category.category}
                    </h4>
                  </div>
                  <div className="space-y-4 pl-9">
                    {category.skills.map((skill, skillIndex) => (
                      <SkillBar key={skill.name} skill={skill} />
                    ))}
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Quick Stats */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8, duration: 0.6 }}
              viewport={{ once: true }}
              className="grid grid-cols-2 gap-6 pt-8"
            >
              <div className="text-center p-6 bg-muted rounded-xl">
                <div className="text-3xl font-bold text-primary">50+</div>
                <div className="text-sm text-muted-foreground">
                  Projects Completed
                </div>
              </div>
              <div className="text-center p-6 bg-muted rounded-xl">
                <div className="text-3xl font-bold text-primary">3+</div>
                <div className="text-sm text-muted-foreground">
                  Years Experience
                </div>
              </div>
              <div className="text-center p-6 bg-muted rounded-xl">
                <div className="text-3xl font-bold text-primary">100%</div>
                <div className="text-sm text-muted-foreground">
                  Client Satisfaction
                </div>
              </div>
              <div className="text-center p-6 bg-muted rounded-xl">
                <div className="text-3xl font-bold text-primary">24/7</div>
                <div className="text-sm text-muted-foreground">
                  Support Available
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;
