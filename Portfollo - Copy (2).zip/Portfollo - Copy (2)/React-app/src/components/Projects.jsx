import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";
import { ExternalLink, Github, Eye, X } from "lucide-react";
import { Button } from "./ui/button";

const Projects = () => {
  const [selectedProject, setSelectedProject] = useState(null);

  const projects = [
    {
      id: 1,
      title: "Movie Search App",
      description:
        "A modern movie discovery platform with real-time search and filtering capabilities.",
      image: "/demo.png",
      category: "Web App",
      technologies: ["React", "Node.js", "API Integration"],
      liveUrl: "/Movie",
      githubUrl: "https://github.com/codewithfitse",
      stats: {
        performance: 95,
        accessibility: 98,
        bestPractices: 92,
        seo: 89,
      },
      caseStudy: {
        problem:
          "Users needed a fast, intuitive way to discover and explore movies with detailed information.",
        solution:
          "Built a responsive React application with real-time search, advanced filtering, and comprehensive movie details.",
        impact:
          "Improved user engagement by 40% and reduced search time by 60%.",
      },
    },
    {
      id: 2,
      title: "Rock Paper Scissors",
      description:
        "Interactive game with AI opponent and beautiful animations.",
      image: "/demo1.png",
      category: "Game",
      technologies: ["JavaScript", "HTML5", "CSS3"],
      liveUrl: "/RPS",
      githubUrl: "https://github.com/codewithfitse",
      stats: {
        performance: 98,
        accessibility: 95,
        bestPractices: 96,
        seo: 85,
      },
      caseStudy: {
        problem:
          "Create an engaging gaming experience that works seamlessly across all devices.",
        solution:
          "Developed a responsive game with smooth animations and intuitive controls.",
        impact: "Achieved 95% user satisfaction and 80% return rate.",
      },
    },
    {
      id: 3,
      title: "Todo Application",
      description:
        "Feature-rich task management app with local storage and modern UI.",
      image: "/demo.png",
      category: "Productivity",
      technologies: ["React", "LocalStorage", "TailwindCSS"],
      liveUrl: "/Todo",
      githubUrl: "https://github.com/codewithfitse",
      stats: {
        performance: 92,
        accessibility: 96,
        bestPractices: 94,
        seo: 88,
      },
      caseStudy: {
        problem:
          "Users needed a simple yet powerful task management tool that works offline.",
        solution:
          "Created a React app with local storage, drag-and-drop functionality, and clean design.",
        impact:
          "Helped users increase productivity by 35% through better task organization.",
      },
    },
    {
      id: 4,
      title: "Head & Tail Game",
      description:
        "Classic coin flip game with modern design and statistics tracking.",
      image: "/demo1.png",
      category: "Game",
      technologies: ["JavaScript", "CSS3", "HTML5"],
      liveUrl: "/Head",
      githubUrl: "https://github.com/codewithfitse",
      stats: {
        performance: 97,
        accessibility: 93,
        bestPractices: 95,
        seo: 87,
      },
      caseStudy: {
        problem:
          "Create an engaging coin flip game with visual feedback and score tracking.",
        solution:
          "Built an interactive game with smooth animations and real-time statistics.",
        impact: "Generated 500+ daily active users with 70% session retention.",
      },
    },
  ];

  const ProjectCard = ({ project, index }) => (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1, duration: 0.6 }}
      viewport={{ once: true }}
      whileHover={{ y: -8 }}
      className="group relative bg-card rounded-xl overflow-hidden border border-border hover:border-primary/50 transition-all duration-300"
    >
      {/* Project Image */}
      <div className="relative overflow-hidden aspect-video">
        <img
          src={project.image}
          alt={project.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

        {/* Overlay Content */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="flex space-x-4">
            <Button
              size="sm"
              onClick={() => setSelectedProject(project)}
              className="bg-white/20 backdrop-blur-sm hover:bg-white/30"
            >
              <Eye className="h-4 w-4 mr-2" />
              View Details
            </Button>
            <Button
              size="sm"
              variant="outline"
              asChild
              className="bg-white/20 backdrop-blur-sm hover:bg-white/30 border-white/30"
            >
              <a href={project.liveUrl}>
                <ExternalLink className="h-4 w-4 mr-2" />
                Live Demo
              </a>
            </Button>
          </div>
        </div>
      </div>

      {/* Project Info */}
      <div className="p-6">
        <div className="flex items-start justify-between mb-3">
          <div>
            <span className="text-xs font-medium text-primary bg-primary/10 px-2 py-1 rounded-full">
              {project.category}
            </span>
          </div>
          <a
            href={project.githubUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <Github className="h-5 w-5" />
          </a>
        </div>

        <h3 className="text-xl font-bold text-foreground mb-2 group-hover:text-primary transition-colors">
          {project.title}
        </h3>
        <p className="text-muted-foreground text-sm leading-relaxed mb-4">
          {project.description}
        </p>

        {/* Technologies */}
        <div className="flex flex-wrap gap-2">
          {project.technologies.map((tech, techIndex) => (
            <span
              key={techIndex}
              className="text-xs bg-muted px-2 py-1 rounded-md text-muted-foreground"
            >
              {tech}
            </span>
          ))}
        </div>
      </div>
    </motion.div>
  );

  const CaseStudyModal = ({ project, onClose }) => (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-card rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto border border-border"
      >
        {/* Header */}
        <div className="p-6 border-b border-border flex items-center justify-between">
          <h2 className="text-2xl font-bold text-foreground">
            {project.title}
          </h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </div>

        <div className="p-6 space-y-6">
          {/* Project Image */}
          <div className="aspect-video rounded-lg overflow-hidden">
            <img
              src={project.image}
              alt={project.title}
              className="w-full h-full object-cover"
            />
          </div>

          {/* Case Study */}
          <div className="grid md:grid-cols-3 gap-6">
            <div className="space-y-3">
              <h3 className="font-semibold text-foreground">Problem</h3>
              <p className="text-muted-foreground text-sm">
                {project.caseStudy.problem}
              </p>
            </div>
            <div className="space-y-3">
              <h3 className="font-semibold text-foreground">Solution</h3>
              <p className="text-muted-foreground text-sm">
                {project.caseStudy.solution}
              </p>
            </div>
            <div className="space-y-3">
              <h3 className="font-semibold text-foreground">Impact</h3>
              <p className="text-muted-foreground text-sm">
                {project.caseStudy.impact}
              </p>
            </div>
          </div>

          {/* Performance Stats */}
          <div className="space-y-4">
            <h3 className="font-semibold text-foreground">
              Performance Metrics
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {Object.entries(project.stats).map(([key, value]) => (
                <div key={key} className="text-center p-4 bg-muted rounded-lg">
                  <div className="text-2xl font-bold text-primary">
                    {value}%
                  </div>
                  <div className="text-xs text-muted-foreground capitalize">
                    {key.replace(/([A-Z])/g, " $1").trim()}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-4 pt-4">
            <Button asChild className="flex-1">
              <a href={project.liveUrl}>
                <ExternalLink className="h-4 w-4 mr-2" />
                View Live Demo
              </a>
            </Button>
            <Button variant="outline" asChild className="flex-1">
              <a
                href={project.githubUrl}
                target="_blank"
                rel="noopener noreferrer"
              >
                <Github className="h-4 w-4 mr-2" />
                View Source Code
              </a>
            </Button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );

  return (
    <section id="projects" className="py-20 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-heading font-bold text-foreground mb-4">
            Featured Projects
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Here are some of my recent projects that showcase my skills and
            passion for creating exceptional digital experiences.
          </p>
        </motion.div>

        {/* Projects Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <ProjectCard key={project.id} project={project} index={index} />
          ))}
        </div>

        {/* View All Projects Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <Button size="lg" variant="outline" asChild>
            <Link to="/Project">
              View All Projects
              <ExternalLink className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </motion.div>
      </div>

      {/* Case Study Modal */}
      <AnimatePresence>
        {selectedProject && (
          <CaseStudyModal
            project={selectedProject}
            onClose={() => setSelectedProject(null)}
          />
        )}
      </AnimatePresence>
    </section>
  );
};

export default Projects;
