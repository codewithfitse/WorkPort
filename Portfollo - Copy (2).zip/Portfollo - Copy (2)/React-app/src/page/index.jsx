import React from 'react'

export const Index = () => {
  return (
    <div className='w-max'>
      <h1 className='text-red-800 pl-5px'>Index</h1>
    </div>
  )
}
